CHAND SHOPPING — ASLI WEBSITE ONLINE KARNE KI GUIDE (HINDI)

Abhi kya ready hai?
- Website ka design aur HTML ready hai.
- Chand ki supplied original photo header aur homepage par rakhi hai.
- Search, categories, sample products aur demo cart chalte hain.

ZAROORI SACH:
Yeh package khud se internet par live nahi hota. Use online karne ke liye hosting account mein files upload karni hongi.
Is version mein real customer orders, database, inventory sync, secure checkout ya UPI payment integration abhi nahi hai. Sample cart real order nahi bhejta.

FREE HOSTING PAR WEBSITE LIVE KARNE KE BASIC STEPS:
1. GitHub.com par account banayein/sign in karein.
2. New repository banayein. Repository ka naam: chand-shopping
3. Is ZIP ko extract karein. index.html aur assets folder ko repository ke root mein upload karein.
   Dhyan: index.html seedha repository ke main page par hona chahiye; kisi extra nested folder ke andar nahi.
4. Repository Settings > Pages kholein.
5. Build and deployment mein Deploy from a branch chunein; branch main aur folder /(root) select karke Save karein.
6. GitHub Pages jo website URL dikhaye, use khol kar test karein. Publish hone mein kuch minute lag sakte hain.

UPI/PAYMENT LAGANE SE PEHLE:
- Payment provider ki official merchant onboarding aur verification complete karein; zaroorat ho to parent/guardian ki madad lein.
- Website ko secure backend/server aur payment provider ke checkout se integrate karna hoga.
- Sirf UPI ID likh dena payment verification, order confirmation, refund ya fraud protection ka badal nahi hai.
- Kabhi bhi customer se UPI PIN/OTP na maangein, aur apna PIN/OTP kisi ko na dein.
- Public launch se pehle shipping, returns/refunds, privacy policy, contact details aur product/pricing ko sahi karein.

PHOTO:
Original photo file assets/chand-photo.png mein hai. Is file ka naam aur assets folder ka path na badlein, warna photo load nahi hogi.
