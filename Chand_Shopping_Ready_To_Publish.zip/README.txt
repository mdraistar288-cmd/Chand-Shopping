CHAND SHOPPING WEBSITE DEMO

How to use:
1. Extract the ZIP file.
2. Keep index.html and the assets folder together.
3. Open index.html in a web browser to preview the website.

Included:
- Responsive Chand Shopping storefront
- Your supplied original photo in the header and homepage (unchanged)
- Sample categories, product search, add-to-cart and cart total

Before a real launch:
- Replace sample products/prices with real inventory.
- Add business contact, shipping/return/privacy policies.
- Connect a backend, secure checkout/payment provider, order management and delivery.
- Buy/connect a domain and hosting, then submit the live site to Google Search Console.
This demo does not accept real orders or payments.
